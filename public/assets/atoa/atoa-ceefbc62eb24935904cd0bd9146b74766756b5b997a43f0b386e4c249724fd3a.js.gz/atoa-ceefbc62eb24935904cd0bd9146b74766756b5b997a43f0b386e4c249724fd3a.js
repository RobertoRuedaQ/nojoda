module.exports = function atoa (a, n) { return Array.prototype.slice.call(a, n); }
;
